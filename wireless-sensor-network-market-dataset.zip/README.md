# Wireless Sensor Network Market Dataset
Structured dataset generated from publicly available information on the Wireless Sensor Network Market page (NextMSC).

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt

License: MIT
